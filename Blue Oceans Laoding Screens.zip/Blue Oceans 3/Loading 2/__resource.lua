--Loading screen made by Matto and W3.css--

files {
 'images/Load_1.jpg',   
 'images/Load_2.jpg',   
 'images/Load_3.jpg',   
 'images/Load_4.jpg',   
 'images/Load_5.jpg',   
 'images/Load_6.jpg',
 'index.html',
 'style.css',
 'w3.css',
}

loadscreen 'index.html'

resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'